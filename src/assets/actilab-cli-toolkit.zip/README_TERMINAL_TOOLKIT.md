# ActiLab Terminal Toolkit — 12 November 2026

This ZIP includes the local ActiLab Python backend code, validation scripts and high-priority metric catalog status.

## Install (Linux / macOS / WSL)

  unzip ActiLab_Terminal_Toolkit_2026-11-12.zip
  cd src
  python3.10 -m venv .venv
  source .venv/bin/activate
  python -m pip install -r backend/requirements.txt
  python -m validation.actilab_cli --help

  python -m validation.actilab_cli /path/to/sample.bin --stage qc --out results/qc

Full instructions: src/docs/CLI_AND_VALIDATION.md

Research-testing release. Requires R/GGIR installed separately for running GGIR. Direct pyActigraphy reference on native GENEActiv BIN or GT3X is *not* an independent native reader; use a common cleaned-epochs input as documented. GGIR-compatible cosinor and sleep-period non-wear fractions are pending. No independent GGIR/ActiLab empirical raw-recording validation completed in this development environment.
