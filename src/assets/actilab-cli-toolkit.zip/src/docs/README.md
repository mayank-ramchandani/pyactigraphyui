# ActiLab user documentation

![ActiLab logo](../assets/actilab-logo.png)

This directory contains the public documentation for researchers and analysts using ActiLab. It focuses on completing the workflow, choosing appropriate settings, understanding outputs, and resolving common user-level problems.

## Start here

1. For command-line analysis and validation, read the [Linux CLI, high-priority catalog, and GGIR/pyActigraphy comparison guide](CLI_AND_VALIDATION.md).
2. Read the [Plug-and-play release guide](PLUG_AND_PLAY_RELEASE.md) for automatic device identification, raw XYZ CSV, epoch lengths, scoring limitations, daily/aggregated outputs and complete metadata.
3. Read [Automatic pipelines by file type](AUTOMATIC_PIPELINES_BY_FORMAT.md) for exactly which reader, library, preprocessing and assumptions ActiLab uses for each supported input.
4. Read the [User guide](USER_GUIDE.md) for the complete ten-step workflow.
5. Review [Initial QC and data-quality settings](PREPROCESSING_VALIDITY_RULES.md) before changing the recommended Analysis settings in Step 7.
6. Check [Supported file formats](FILE_FORMATS.md) and [Choosing an activity representation](ACTIVITY_PROCESSING.md) when preparing data.
7. Use [Metrics and algorithms](METRICS_AND_ALGORITHMS.md) to understand the available analyses.
8. Use [Troubleshooting](DIAGNOSTICS_AND_TROUBLESHOOTING.md) when a result is missing or a run fails.

## Documentation by task

| I need to… | Read… |
|---|---|
| Configure plug-and-play raw processing, CSV XYZ import, epochs and reproducible summary exports | [Plug-and-play release guide](PLUG_AND_PLAY_RELEASE.md) |
| Understand the automatic reader/processing source for every format | [Automatic pipelines by file type](AUTOMATIC_PIPELINES_BY_FORMAT.md) |
| Export Step 2 QC results without completing analysis | [User guide — Step 2](USER_GUIDE.md#2-preprocessinginitial-qc) |
| Process files on a Linux machine, use raw non-wear QC, and compare three tools statistically | [Command-line and validation guide](CLI_AND_VALIDATION.md) |
| Review the uploaded workbook metrics against completed code and limitations | [Metric catalog implementation status](METRIC_CATALOG_IMPLEMENTATION_STATUS.csv) |
| Compare matched results against GGIR | [GGIR validation protocol](GGIR_COMPARISON_PROTOCOL.md) |
| Browse candidate metrics from GGIR and pyActigraphy (not all implemented) | [Candidate metric catalogue](METRIC_CATALOG_CANDIDATES.csv) |
| Complete an analysis from upload to export | [User guide](USER_GUIDE.md) |
| Customize raw X/Y/Z filtering, acceleration magnitude and gravity normalization | [Methods and reproducibility](PREPROCESSING_AND_PROVENANCE.md#configurable-raw-acceleration-pipeline-step-2) |
| Decide whether to keep or change the recommended quality thresholds | [Initial QC and data-quality settings](PREPROCESSING_VALIDITY_RULES.md) |
| Confirm whether a recording or CSV layout is supported | [Supported file formats](FILE_FORMATS.md) |
| Choose between processed acceleration, ENMO, MAD, PIM, ZCM, TAT, or source counts | [Choosing an activity representation](ACTIVITY_PROCESSING.md) |
| Join recordings collected at different native sampling rates | [Choosing an activity representation](ACTIVITY_PROCESSING.md#joining-recordings-with-different-native-sampling-rates) |
| Understand RA, IS, IV, SRI, sleep metrics, fragmentation, or Cosinor | [Metrics and algorithms](METRICS_AND_ALGORITHMS.md) |
| Download epoch-level preprocessed activity values, masks and settings | [User guide — Data export](USER_GUIDE.md#download-the-preprocessed-activity-time-series) |
| Understand how preprocessing choices are recorded | [Methods and reproducibility](PREPROCESSING_AND_PROVENANCE.md) |
| Resolve warnings, unavailable metrics, upload errors, or missing sleep windows | [Troubleshooting](DIAGNOSTICS_AND_TROUBLESHOOTING.md) |
| Review privacy, data handling, and acceptable use | [Terms of use](TERMS_OF_USE.md) |
| See recent user-visible changes | [What’s new](CHANGELOG.md) |

## Workflow

1. Importing Actigraphy Files
2. Preprocessing/Initial QC
3. Estimating Activity Metric
4. Activity Preview
5. Cleaning and Masking
6. Sleep-wake Classification
7. Analysis Set-up
8. Other Sensors
9. Generate Results
10. Export Outputs

After at least one actigraphy file is uploaded, Steps 2–9 can be opened directly from the left workflow. Export unlocks after results are generated successfully.

## Key terms

- **Activity representation:** the one-dimensional epoch-level series used for actigraphy calculations, such as device counts, processed acceleration, ENMO, MAD, PIM, ZCM, or TAT.
- **Analytical epoch:** the common epoch duration used after raw processing (for example, 30 seconds); this is different from the device's native sampling rate in Hz.
- **Analyzable time:** recorded time that remains after gaps, non-wear, start/stop limits, and masks are applied.
- **Valid quality window:** a calendar day or recording-aligned 24-hour window that meets the selected minimum analyzable-hours threshold.
- **Sleep-window coverage:** the proportion of expected epochs inside a sleep window that remain available and scorable.
- **Unavailable result:** a metric that could not be calculated because required data, valid windows, sleep windows, or supported signals were not available.
- **Warning:** processing continued, but the result or data quality requires review.

Last updated: **2026-11-12**.
