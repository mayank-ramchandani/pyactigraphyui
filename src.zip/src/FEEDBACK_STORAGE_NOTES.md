# Feedback storage and access

## Where submissions go

The floating feedback form sends:

```text
POST /api/feedback
```

The backend appends one JSON object per line to:

```text
${APP_DATA_DIR}/feedback.jsonl
```

When `APP_DATA_DIR` is unset, the path is:

```text
/tmp/actigraphy-ui-data/feedback.jsonl
```

`/tmp` is container-local and normally disappears when the instance is replaced. For OBI/Azure, mount a persistent Azure Files volume and set `APP_DATA_DIR` to that mount, for example:

```text
APP_DATA_DIR=/data/actigraphy-ui
```

The backend, not Vercel, stores the report. The storage location therefore follows the backend selected by `VITE_API_BASE_URL`.

## Required email and 30-day retention

A valid contact email is required so the Centre for Analytics team can follow up about the submitted issue, question, or suggestion. The email address is stored with the report.

Each feedback record, its contact email, and its attached technical context are retained for 30 days from the UTC submission timestamp. Records whose retention period has elapsed are removed from `feedback.jsonl` by:

- cleanup when the backend starts;
- automatic cleanup every 24 hours while the backend is running; and
- cleanup before a feedback submission is appended or feedback is listed/exported.

The cleanup rewrites the JSONL file atomically with only current records. Records with missing or invalid submission timestamps are also removed rather than retained indefinitely.

## Information stored with each report

The form does not upload raw actigraphy data. It stores the user's message plus diagnostic context:

- feedback ID and UTC submission time;
- category and required contact email, used to follow up about the report;
- current workflow step and client URL;
- selected file names, extensions, sizes, and analysis selection state;
- current endpoint, request ID, job/progress state, and visible errors;
- activity mapping, analysis mode/scope, selected families/metrics, sleep settings, preprocessing settings, analysis windows, and light selections;
- frontend version, backend URL, browser information, and client timestamp.

## Review in the application

After `FEEDBACK_ADMIN_TOKEN` is configured on the backend, open:

```text
https://YOUR-FRONTEND/?feedback-admin=1
```

Enter the administrator token to search reports, inspect the complete stored context, and download CSV or JSONL exports. The token is retained only in browser session storage for the current tab.

## Protected API access

Set a long random backend secret:

```text
FEEDBACK_ADMIN_TOKEN=replace-with-a-long-random-secret
```

Then list recent reports:

```bash
curl -H "X-Feedback-Admin-Token: $FEEDBACK_ADMIN_TOKEN" \
  "https://YOUR-BACKEND/api/admin/feedback?limit=100"
```

Optional filters:

```text
/api/admin/feedback?category=issue&search=gt3x&limit=250
```

Download CSV:

```bash
curl -L -H "Authorization: Bearer $FEEDBACK_ADMIN_TOKEN" \
  "https://YOUR-BACKEND/api/admin/feedback/export?format=csv" \
  -o feedback.csv
```

Download JSONL by changing `format=jsonl`.

The list/export endpoints return `503` until `FEEDBACK_ADMIN_TOKEN` is configured and `401` for an incorrect token.

## Local/container export

From the source directory:

```bash
python -m backend.export_feedback \
  --format csv \
  --output feedback.csv
```

Specify `--input /mounted/path/feedback.jsonl` when exporting a copied or mounted feedback file.


## Email notification

After feedback is safely stored, the backend can send a minimal notification to `mramchandani@stjoes.ca` (or `FEEDBACK_NOTIFICATION_TO`). Configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_FROM`, and, when required, `SMTP_USERNAME` / `SMTP_PASSWORD` in the Azure Container App environment/secrets. The email contains only the feedback ID, submitter email, filename, workflow step, and category. It intentionally excludes the free-text feedback and detailed diagnostic/configuration context. A mail-delivery failure does not discard the stored feedback submission.
