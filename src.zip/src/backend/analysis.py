import copy
import math
import numbers
import pandas as pd


def _get_light_recording(raw):
    light_obj = getattr(raw, "light", None)
    if light_obj is None or not hasattr(light_obj, "get_channel_list"):
        return None
    return light_obj


def _get_light_channels(raw):
    light_obj = _get_light_recording(raw)
    if light_obj is None:
        return []
    try:
        return [str(c) for c in light_obj.get_channel_list()]
    except Exception:
        return []


def _pick_default_light_channel(channels):
    if not channels:
        return None
    lowered = {c.lower(): c for c in channels}
    for preferred in ["weißes licht", "weisses licht", "white light", "whitelight", "light", "amb light"]:
        if preferred in lowered:
            return lowered[preferred]
    return channels[0]




def _normalize_light_time_arg(value):
    if value is None or value == "":
        return None
    text = str(value).strip()
    if not text:
        return None
    if "T" in text or ("-" in text and ":" in text):
        parsed = pd.to_datetime(text, errors="coerce")
        if parsed is not pd.NaT and not pd.isna(parsed):
            return parsed.strftime("%H:%M:%S")
    if len(text) == 5 and text.count(":") == 1:
        return text + ":00"
    return text

def _lux_to_log10_threshold(threshold_lux):
    if threshold_lux is None or threshold_lux == "":
        return None
    try:
        lux = float(threshold_lux)
    except Exception:
        return None
    if lux < 0:
        return None
    return math.log10(lux + 1.0)


def _serialize_scalar(value, ndigits=2):
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except Exception:
        pass
    if isinstance(value, bool):
        return value
    if isinstance(value, numbers.Number):
        value = float(value)
        if math.isfinite(value):
            return round(value, ndigits)
        return None
    if isinstance(value, str):
        return value
    try:
        numeric = float(value)
        if math.isfinite(numeric):
            return round(numeric, ndigits)
    except Exception:
        return str(value)
    return str(value)


def _serialize_series(series):
    return {"kind": "series", "index": [str(i) for i in series.index.tolist()], "values": [_serialize_scalar(v) for v in series.tolist()], "name": str(series.name) if series.name is not None else None}


def _serialize_dataframe(df):
    if isinstance(df.columns, pd.MultiIndex):
        columns = [" | ".join([str(x) for x in col if x is not None]) for col in df.columns.tolist()]
    else:
        columns = [str(c) for c in df.columns.tolist()]
    rows = []
    for idx, row in df.iterrows():
        rows.append({"index": str(idx), "values": [_serialize_scalar(v) for v in row.tolist()]})
    return {"kind": "dataframe", "columns": columns, "rows": rows}


def _select_channel_from_result(result, channel):
    if channel is None:
        return result
    if isinstance(result, pd.Series):
        if channel in result.index:
            return result.loc[channel]
        return result
    if isinstance(result, pd.DataFrame):
        if "channel" in result.columns:
            filtered = result[result["channel"].astype(str) == str(channel)]
            if not filtered.empty:
                return filtered
        if isinstance(result.columns, pd.MultiIndex):
            if channel in result.columns.get_level_values(0):
                return result[channel]
        elif channel in result.columns:
            return result[channel]
        return result
    return result


def _values_by_channel(df):
    if isinstance(df, pd.DataFrame) and "channel" in df.columns and "value" in df.columns:
        return df.set_index("channel")["value"]
    return pd.Series(dtype=float)


def run_basic_pylight_analysis(raw, metric_id, channel=None, threshold_lux=None, start_time=None, stop_time=None, bins="24h", agg="mean", agg_funcs=None, oformat="minute", lmx_length="5h", lowest=True, binarize=False):
    light_obj = _get_light_recording(raw)
    if light_obj is None:
        raise ValueError("No light recording is available on the loaded file.")
    channels = _get_light_channels(raw)
    if not channels:
        raise ValueError("No light channels are available on the loaded file.")
    if channel is None:
        channel = _pick_default_light_channel(channels)
    threshold = _lux_to_log10_threshold(threshold_lux)
    start_time = _normalize_light_time_arg(start_time)
    stop_time = _normalize_light_time_arg(stop_time)

    if metric_id == "exposure_level":
        result = light_obj.light_exposure_level(threshold=threshold, start_time=start_time or None, stop_time=stop_time or None, agg=agg or "mean")
        result = _select_channel_from_result(result, channel)
    elif metric_id == "summary_stats":
        result = light_obj.summary_statistics_per_time_bin(bins=bins or "24h", agg_func=agg_funcs or ["mean", "median", "sum", "std", "min", "max"])
        result = _select_channel_from_result(result, channel)
    elif metric_id == "tat":
        result = light_obj.TAT(threshold=threshold, start_time=start_time or None, stop_time=stop_time or None, oformat=oformat or "minute")
        result = _select_channel_from_result(result, channel)
    elif metric_id == "tatp":
        result = light_obj.TATp(threshold=threshold, start_time=start_time or None, stop_time=stop_time or None, oformat=oformat or "minute")
        result = _select_channel_from_result(result, channel)
    elif metric_id == "mlit":
        if threshold is None:
            raise ValueError("MLiT requires a lux threshold such as 10, 100, or 500.")
        result = light_obj.MLiT(threshold=threshold)
        result = _select_channel_from_result(result, channel)
    elif metric_id == "extremum_min":
        result = light_obj.get_light_extremum(extremum="min")
        result = _select_channel_from_result(result, channel)
    elif metric_id == "extremum_max":
        result = light_obj.get_light_extremum(extremum="max")
        result = _select_channel_from_result(result, channel)
    elif metric_id in {"l5", "m10"}:
        result = light_obj.LMX(length="5h" if metric_id == "l5" else "10h", lowest=(metric_id == "l5"))
        result = _select_channel_from_result(result, channel)
    elif metric_id == "lmx":
        result = light_obj.LMX(length=lmx_length or "5h", lowest=bool(lowest))
        result = _select_channel_from_result(result, channel)
    elif metric_id == "is":
        result = light_obj.IS(binarize=bool(binarize), threshold=threshold or 0)
        result = _select_channel_from_result(result, channel)
    elif metric_id == "iv":
        result = light_obj.IV(binarize=bool(binarize), threshold=threshold or 0)
        result = _select_channel_from_result(result, channel)
    elif metric_id == "ra":
        l5_values = _values_by_channel(light_obj.LMX(length="5h", lowest=True))
        m10_values = _values_by_channel(light_obj.LMX(length="10h", lowest=False))
        common = [ch for ch in m10_values.index if ch in l5_values.index]
        result = pd.Series({ch: ((m10_values.loc[ch] - l5_values.loc[ch]) / (m10_values.loc[ch] + l5_values.loc[ch]) if (m10_values.loc[ch] + l5_values.loc[ch]) != 0 else None) for ch in common}, name="RA")
        result = _select_channel_from_result(result, channel)
    elif metric_id == "vat":
        if threshold is None:
            raise ValueError("VAT requires a lux threshold such as 10 or 100.")
        result = light_obj.VAT(threshold)
        result = _select_channel_from_result(result, channel)
    else:
        raise ValueError("Unsupported light metric '{}'.".format(metric_id))

    if isinstance(result, pd.DataFrame):
        payload = _serialize_dataframe(result)
    elif isinstance(result, pd.Series):
        payload = _serialize_series(result)
    else:
        payload = {"kind": "scalar", "value": _serialize_scalar(result)}
    return {"metric_id": metric_id, "channel": channel, "available_channels": channels, "threshold_lux": _serialize_scalar(threshold_lux), "threshold_log10": _serialize_scalar(threshold), "result": payload}


def get_basic_light_channels(raw):
    channels = _get_light_channels(raw)
    return {"channels": channels, "default_channel": _pick_default_light_channel(channels)}


def _light_dataframe(raw, channels=None):
    requested = channels or _get_light_channels(raw)
    series_map = {}
    for channel in requested:
        series = _get_light_channel_series(raw, channel)
        if series is not None and len(series) > 0:
            series_map[channel] = series.rename(channel)
    if not series_map:
        raise ValueError("No usable light channel data were found.")
    return pd.concat(series_map.values(), axis=1).sort_index()


def manipulate_light_data(raw, channels=None, truncate_start=None, truncate_stop=None, daily_start_time=None, daily_stop_time=None, resample_freq=None, binarize=False, threshold_lux=None, filter_method="none", filter_window="15min", max_points=1200):
    df = _light_dataframe(raw, channels=channels)
    original_rows = len(df)
    if truncate_start:
        df = df.loc[pd.to_datetime(truncate_start):]
    if truncate_stop:
        df = df.loc[:pd.to_datetime(truncate_stop)]
    if daily_start_time and daily_stop_time:
        start = pd.to_datetime(daily_start_time).time()
        stop = pd.to_datetime(daily_stop_time).time()
        times = df.index.time
        if start <= stop:
            mask = [(t >= start and t <= stop) for t in times]
        else:
            mask = [(t >= start or t <= stop) for t in times]
        df = df.loc[mask]
    if resample_freq:
        df = df.resample(resample_freq).mean()
    if filter_method in {"mean", "median"}:
        rolled = df.rolling(filter_window, min_periods=1)
        df = rolled.mean() if filter_method == "mean" else rolled.median()
    threshold = _lux_to_log10_threshold(threshold_lux)
    if binarize:
        if threshold is None:
            raise ValueError("Binarization requires a lux threshold.")
        df = (df > threshold).astype(int)
    df = df.dropna(how="all")
    return {"light_manipulation_available": True, "channels": list(df.columns), "summary": {"original_rows": int(original_rows), "rows": int(len(df)), "start": str(df.index.min()) if len(df) else None, "end": str(df.index.max()) if len(df) else None, "threshold_lux": _serialize_scalar(threshold_lux), "threshold_log10": _serialize_scalar(threshold), "resample_freq": resample_freq, "filter_method": filter_method, "filter_window": filter_window, "binarized": bool(binarize)}, "preview": _sample_multichannel_dataframe(df, max_points=max_points)}

DEFAULT_MEAN_FREQS = [
    "1min", "2min", "3min", "4min", "5min", "6min", "8min", "9min", "10min",
    "12min", "15min", "16min", "18min", "20min", "24min", "30min", "32min",
    "36min", "40min", "45min", "48min", "60min",
]

ALGO_TO_SRI_KEY = {
    "cole_kripke": "CK",
    "sadeh": "Sadeh",
    "oakley": "Oakley",
    "scripps": "Scripps",
    "crespo": "Crespo",
    "roenneberg": "Roenneberg",
}

IMPLEMENTED_FAMILY_METRICS = {
    "amplitude": ["ra", "rap"],
    "rhythm": ["is", "iv", "ism", "ivm", "isp", "ivp"],
    "sleep": ["sri", "tst", "waso", "sleep_efficiency"],
    "fragmentation": ["kra", "kar"],
}

ADVANCED_FAMILY_IDS = {"cosinor", "flm", "mfdfa", "ssa", "clustering"}


def _safe_float(value):
    try:
        return float(value)
    except Exception:
        return value


def _safe_call(callable_obj, *args, **kwargs):
    try:
        return callable_obj(*args, **kwargs)
    except Exception:
        return None


def _resolve_series_to_numeric(value):
    if value is None:
        return None
    try:
        return float(value)
    except Exception:
        return value


def _call_raw_method(raw, method_name, *args, **kwargs):
    method = getattr(raw, method_name, None)
    if method is None or not callable(method):
        return None
    return _safe_call(method, *args, **kwargs)


def _score_algorithm(raw, algorithm, algorithm_params=None):
    algorithm_params = algorithm_params or {}
    params = algorithm_params.get(algorithm, {}) if isinstance(algorithm_params, dict) else {}

    if algorithm == "cole_kripke":
        method = getattr(raw, "CK", None)
        if method is None or not callable(method):
            return None
        settings = params.get("settings") or "30sec_max_non_overlap"
        threshold = params.get("threshold", 1.0)
        rescoring = params.get("rescoring", True)
        attempts = [
            {"settings": settings, "threshold": threshold, "rescoring": rescoring},
            {"settings": "mean", "threshold": threshold, "rescoring": rescoring},
            {},
        ]
        seen = set()
        for kwargs in attempts:
            key = tuple(sorted(kwargs.items()))
            if key in seen:
                continue
            seen.add(key)
            try:
                return method(**kwargs)
            except Exception:
                continue
        return None
    if algorithm == "sadeh":
        return _call_raw_method(raw, "Sadeh")
    if algorithm == "scripps":
        return _call_raw_method(raw, "Scripps")
    if algorithm == "oakley":
        threshold_mode = params.get("thresholdMode", ["auto"])
        if isinstance(threshold_mode, str):
            threshold_mode = [threshold_mode]
        mode = threshold_mode[0] if threshold_mode else "auto"
        threshold = "automatic" if mode == "auto" else params.get("manualThreshold", 40)
        return _call_raw_method(raw, "Oakley", threshold=threshold)
    if algorithm == "crespo":
        method = getattr(raw, "Crespo", None)
        if method is None or not callable(method):
            return None
        kwargs = {}
        for key in ["zeta", "zeta_r", "zeta_a", "t", "alpha", "beta", "estimate_zeta", "seq_length_max", "verbose"]:
            if key in params and params[key] not in (None, ""):
                kwargs[key] = params[key]
        scored = _safe_call(method, **kwargs) if kwargs else None
        if scored is not None:
            return scored
        alpha_mode = params.get("alphaMode", "default")
        if alpha_mode == "manual":
            alpha = "{}h".format(params.get("alpha", 8))
            return _safe_call(method, alpha=alpha)
        if alpha_mode == "auto":
            return _safe_call(method, estimate_zeta=True)
        return _safe_call(method)
    if algorithm == "roenneberg":
        method = getattr(raw, "Roenneberg", None)
        if method is None or not callable(method):
            return None
        kwargs = {}
        for key in ["trend_period", "min_trend_period", "threshold", "min_seed_period", "max_test_period", "r_consec_below", "rsfreq"]:
            if key in params and params[key] not in (None, ""):
                kwargs[key] = params[key]
        scored = _safe_call(method, **kwargs) if kwargs else None
        if scored is not None:
            return scored
        factors = params.get("thresholdFactors") or [0.15]
        factor = 0.15
        if isinstance(factors, str):
            try:
                factor = float(factors.split(",")[0].strip())
            except Exception:
                factor = 0.15
        elif isinstance(factors, list) and len(factors) > 0:
            try:
                factor = float(factors[0])
            except Exception:
                factor = 0.15
        return _safe_call(method, threshold=factor)
    return None


def _epoch_minutes(index):
    try:
        freq = getattr(index, "freq", None) or pd.infer_freq(index)
        if freq is not None:
            return pd.Timedelta(freq).total_seconds() / 60.0
    except Exception:
        pass
    try:
        diffs = pd.Series(index).diff().dropna()
        if len(diffs) > 0:
            return diffs.median().total_seconds() / 60.0
    except Exception:
        pass
    return 1.0


def _coerce_score_series(score):
    if score is None:
        return None
    if isinstance(score, pd.DataFrame):
        if score.shape[1] == 1:
            score = score.iloc[:, 0]
        else:
            numeric_cols = score.select_dtypes(include="number").columns
            if len(numeric_cols) == 0:
                return None
            score = score[numeric_cols[0]]
    if not isinstance(score, pd.Series):
        try:
            score = pd.Series(score)
        except Exception:
            return None
    numeric = pd.to_numeric(score, errors="coerce").dropna()
    return numeric if len(numeric) else None


def _score_rest_minutes(score):
    series = _coerce_score_series(score)
    if series is None:
        return None
    return float((series > 0).sum()) * _epoch_minutes(series.index)


def _normalize_sleep_window(window, default_source="sleep_diary"):
    try:
        start = pd.to_datetime(window.get("start"))
        stop = pd.to_datetime(window.get("stop"))
        if pd.isna(start) or pd.isna(stop) or stop <= start:
            return None
        return {
            "start": start,
            "stop": stop,
            "state": str(window.get("state", "NIGHT")),
            "source": str(window.get("source", default_source)),
            "method": str(window.get("method", default_source)),
            "estimated": bool(window.get("estimated", default_source != "sleep_diary")),
        }
    except Exception:
        return None


def _get_sleep_windows(raw):
    windows = getattr(raw, "_ui_sleep_windows", None) or []
    normalized = []
    for window in windows:
        normalized_window = _normalize_sleep_window(window, default_source="sleep_diary")
        if normalized_window is not None:
            normalized.append(normalized_window)
    return normalized


def _flatten_aot_times(values):
    if values is None:
        return []
    try:
        if isinstance(values, pd.Series):
            values = values.dropna().tolist()
        elif isinstance(values, pd.DataFrame):
            values = values.stack().dropna().tolist()
    except Exception:
        pass
    if not isinstance(values, (list, tuple, set)):
        try:
            values = list(values)
        except Exception:
            values = [values]
    flattened = []
    for value in values:
        if isinstance(value, (list, tuple, set)):
            flattened.extend(_flatten_aot_times(value))
            continue
        try:
            ts = pd.to_datetime(value)
            if not pd.isna(ts):
                flattened.append(ts)
        except Exception:
            continue
    return sorted(set(flattened))


def _call_aot_method(raw, method_name, params=None):
    params = params or {}
    method = getattr(raw, method_name, None)
    if method is None or not callable(method):
        return None
    try:
        if method_name == "Crespo_AoT":
            kwargs = {}
            for key in ["zeta", "zeta_r", "zeta_a", "t", "alpha", "beta", "estimate_zeta", "seq_length_max", "verbose"]:
                if key in params and params[key] not in (None, ""):
                    kwargs[key] = params[key]
            return method(**kwargs)
        if method_name == "Roenneberg_AoT":
            kwargs = {}
            for key in [
                "trend_period",
                "min_trend_period",
                "threshold",
                "min_seed_period",
                "max_test_period",
                "r_consec_below",
                "rsfreq",
            ]:
                if key in params and params[key] not in (None, ""):
                    kwargs[key] = params[key]
            return method(**kwargs)
        return method()
    except Exception:
        return None


def _rest_windows_from_activity_onset_offset(onsets, offsets, min_hours=3.0, max_hours=14.0):
    onset_times = _flatten_aot_times(onsets)
    offset_times = _flatten_aot_times(offsets)
    windows = []
    if not onset_times or not offset_times:
        return windows

    for offset in offset_times:
        next_onsets = [onset for onset in onset_times if onset > offset]
        if not next_onsets:
            continue
        onset = next_onsets[0]
        duration_hours = (onset - offset).total_seconds() / 3600.0
        if min_hours <= duration_hours <= max_hours:
            windows.append({
                "start": offset,
                "stop": onset,
                "state": "ESTIMATED_REST",
                "source": "estimated_rest_period",
                "method": "activity_offset_to_next_onset",
                "estimated": True,
            })

    # Dedupe overlapping/identical windows.
    deduped = []
    seen = set()
    for window in sorted(windows, key=lambda item: item["start"]):
        key = (str(window["start"]), str(window["stop"]))
        if key in seen:
            continue
        seen.add(key)
        deduped.append(window)
    return deduped


def _format_clock_hour(hour):
    try:
        hour = int(hour) % 24
    except Exception:
        hour = 0
    suffix = "AM" if hour < 12 else "PM"
    display_hour = hour % 12
    if display_hour == 0:
        display_hour = 12
    return f"{display_hour}:00 {suffix}"


def _safe_iso_timestamp(value):
    try:
        return pd.Timestamp(value).isoformat()
    except Exception:
        return str(value)


def _safe_round(value, digits=4):
    try:
        if value is None or pd.isna(value):
            return None
        return round(float(value), digits)
    except Exception:
        return None


def _format_window_label(start, stop):
    try:
        start_ts = pd.Timestamp(start)
        stop_ts = pd.Timestamp(stop)
        return f"{start_ts.strftime('%Y-%m-%d %I:%M %p')} to {stop_ts.strftime('%Y-%m-%d %I:%M %p')}"
    except Exception:
        return f"{start} to {stop}"


def _sleep_window_detail_payload(windows, window_metadata=None):
    metadata = window_metadata or {}
    details = []
    for idx, window in enumerate(windows or [], start=1):
        start = window.get("start")
        stop = window.get("stop")
        duration_hours = None
        try:
            duration_hours = (pd.Timestamp(stop) - pd.Timestamp(start)).total_seconds() / 3600.0
        except Exception:
            duration_hours = window.get("duration_hours")

        detail = {
            "index": idx,
            "date": window.get("night") or window.get("date") or _safe_iso_timestamp(start)[:10],
            "method": window.get("method") or metadata.get("method"),
            "source": window.get("source") or metadata.get("source"),
            "estimated": bool(window.get("estimated", metadata.get("estimated", False))),
            "start": _safe_iso_timestamp(start),
            "stop": _safe_iso_timestamp(stop),
            "duration_hours": _safe_round(duration_hours, 3),
        }

        diagnostics = window.get("diagnostics") or {}
        if diagnostics:
            detail.update({
                "expected_search_start": diagnostics.get("search_start"),
                "expected_search_stop": diagnostics.get("search_stop"),
                "expected_search_range": diagnostics.get("search_range_label"),
                "lowest_sustained_activity_block_start": diagnostics.get("candidate_start"),
                "lowest_sustained_activity_block_stop": diagnostics.get("candidate_stop"),
                "lowest_sustained_activity_block": diagnostics.get("candidate_range_label"),
                "target_window_hours": diagnostics.get("target_hours"),
                "min_window_hours": diagnostics.get("min_hours"),
                "max_window_hours": diagnostics.get("max_hours"),
                "resample_frequency": diagnostics.get("resample_frequency"),
                "rolling_mean_activity": diagnostics.get("rolling_mean_activity"),
                "segment_mean_activity": diagnostics.get("segment_mean_activity"),
                "segment_min_activity": diagnostics.get("segment_min_activity"),
                "segment_max_activity": diagnostics.get("segment_max_activity"),
                "points_in_search_range": diagnostics.get("points_in_search_range"),
                "points_in_detected_window": diagnostics.get("points_in_detected_window"),
            })
        details.append(detail)
    return details


def _summarize_sleep_window_details(details, max_items=4):
    if not details:
        return ""
    lines = []
    for item in details[:max_items]:
        lines.append(
            "Date {date}: expected overnight search range {search}; "
            "lowest sustained activity block {block}; fallback sleep/rest window {window}; "
            "duration {duration} h; rolling mean activity {activity}.".format(
                date=item.get("date") or "unknown",
                search=item.get("expected_search_range") or "not recorded",
                block=item.get("lowest_sustained_activity_block") or f"{item.get('start')} to {item.get('stop')}",
                window=f"{item.get('start')} to {item.get('stop')}",
                duration=item.get("duration_hours") if item.get("duration_hours") is not None else "not available",
                activity=item.get("rolling_mean_activity") if item.get("rolling_mean_activity") is not None else "not available",
            )
        )
    if len(details) > max_items:
        lines.append(f"Additional fallback windows detected: {len(details) - max_items}.")
    return " | ".join(lines)


def _detect_low_activity_rest_windows(raw, min_hours=3.0, max_hours=14.0, target_hours=None, search_start_hour=20, search_stop_hour=12):
    """Fallback rest-window detector for raw objects without usable AOT arrays.

    It finds the lowest-activity overnight window for each recording day. This is
    deliberately labelled as a fallback estimate so users know it is not a
    pyActigraphy Crespo/Roenneberg AOT result. The returned windows include
    diagnostic metadata so the UI can show the search range and selected block.
    """
    series = getattr(raw, "data", None)
    if series is None:
        return []
    try:
        series = pd.to_numeric(series, errors="coerce").dropna().sort_index()
    except Exception:
        return []
    if len(series) == 0 or not isinstance(series.index, pd.DatetimeIndex):
        return []

    try:
        # Five-minute bins keep this fallback fast on large GENEActiv files and
        # make the rolling overnight search less sensitive to single-epoch spikes.
        work = series.resample("5min").mean().dropna()
    except Exception:
        work = series

    if len(work) == 0:
        return []

    target_hours = float(target_hours or min(max(8.0, min_hours), max_hours))
    target_hours = min(max(target_hours, min_hours), max_hours)
    duration = pd.Timedelta(hours=target_hours)
    min_duration = pd.Timedelta(hours=min_hours)

    try:
        search_start_hour = int(search_start_hour) % 24
    except Exception:
        search_start_hour = 20
    try:
        search_stop_hour = int(search_stop_hour) % 24
    except Exception:
        search_stop_hour = 12

    start_date = work.index.min().normalize() - pd.Timedelta(days=1)
    end_date = work.index.max().normalize() + pd.Timedelta(days=1)
    dates = pd.date_range(start_date, end_date, freq="1D")
    windows = []

    for date in dates:
        night_start = date + pd.Timedelta(hours=search_start_hour)
        night_stop = date + pd.Timedelta(hours=search_stop_hour)
        if night_stop <= night_start:
            night_stop = night_stop + pd.Timedelta(days=1)
        segment = work.loc[night_start:night_stop].dropna()
        if segment.empty:
            continue
        if (segment.index.max() - segment.index.min()) < min_duration:
            continue
        if (segment.index.max() - segment.index.min()) < duration:
            # Do not report a target-length fallback window if the recording only
            # contains a partial edge of the overnight search range.
            continue

        try:
            rolling = segment.rolling(duration, min_periods=max(2, int((min_hours * 60) / 5))).mean().dropna()
        except Exception:
            rolling = segment.rolling(max(2, int((target_hours * 60) / 5)), min_periods=max(2, int((min_hours * 60) / 5))).mean().dropna()
        if rolling.empty:
            continue

        stop = pd.Timestamp(rolling.idxmin())
        start = stop - duration
        if start < segment.index.min():
            start = segment.index.min()
            stop = start + duration
        if stop > segment.index.max():
            stop = segment.index.max()
            start = stop - duration
        if stop <= start or (stop - start) < min_duration:
            continue

        duration_hours = (stop - start).total_seconds() / 3600.0
        if not (min_hours <= duration_hours <= max_hours):
            continue

        window_segment = segment.loc[start:stop].dropna()
        diagnostics = {
            "night": date.date().isoformat(),
            "search_start": _safe_iso_timestamp(night_start),
            "search_stop": _safe_iso_timestamp(night_stop),
            "search_range_label": f"{_format_clock_hour(search_start_hour)} to {_format_clock_hour(search_stop_hour)} next day",
            "candidate_start": _safe_iso_timestamp(start),
            "candidate_stop": _safe_iso_timestamp(stop),
            "candidate_range_label": _format_window_label(start, stop),
            "target_hours": _safe_round(target_hours, 3),
            "min_hours": _safe_round(min_hours, 3),
            "max_hours": _safe_round(max_hours, 3),
            "resample_frequency": "5min",
            "rolling_mean_activity": _safe_round(rolling.loc[stop] if stop in rolling.index else rolling.min(), 6),
            "segment_mean_activity": _safe_round(segment.mean(), 6),
            "segment_min_activity": _safe_round(segment.min(), 6),
            "segment_max_activity": _safe_round(segment.max(), 6),
            "points_in_search_range": int(len(segment)),
            "points_in_detected_window": int(len(window_segment)),
        }

        windows.append({
            "start": start,
            "stop": stop,
            "night": date.date().isoformat(),
            "duration_hours": duration_hours,
            "state": "ESTIMATED_REST",
            "source": "estimated_rest_period",
            "method": "fallback_low_activity_window",
            "estimated": True,
            "diagnostics": diagnostics,
        })

    deduped = []
    seen_dates = set()
    for window in sorted(windows, key=lambda item: item["start"]):
        key = str(window.get("night") or window["start"].date().isoformat())
        if key in seen_dates:
            continue
        seen_dates.add(key)
        deduped.append(window)
    return deduped


def _detect_rest_windows_with_pyactigraphy(raw, sleep_window_settings=None):
    settings = sleep_window_settings or {}
    enabled = bool(settings.get("estimateWithoutDiary", True))
    if not enabled:
        return [], {"source": "none", "method": None, "estimated": False, "notes": ["No-diary rest-window estimation disabled."]}

    method_preference = settings.get("method") or "crespo_aot"
    min_hours = float(settings.get("minRestWindowHours", 3) or 3)
    max_hours = float(settings.get("maxRestWindowHours", 14) or 14)
    notes = []

    method_order = [method_preference]
    for fallback in ["crespo_aot", "roenneberg_aot"]:
        if fallback not in method_order:
            method_order.append(fallback)

    for method_name in method_order:
        if method_name == "crespo_aot":
            aot = _call_aot_method(raw, "Crespo_AoT", settings.get("crespoParams", {}))
            label = "pyActigraphy Crespo_AoT"
        elif method_name == "roenneberg_aot":
            aot = _call_aot_method(raw, "Roenneberg_AoT", settings.get("roennebergParams", {}))
            label = "pyActigraphy Roenneberg_AoT"
        else:
            notes.append(f"Unknown rest-window detection method: {method_name}.")
            continue

        if not aot or not isinstance(aot, (list, tuple)) or len(aot) < 2:
            notes.append(f"{label} did not return usable activity onset/offset arrays.")
            continue

        onsets, offsets = aot[0], aot[1]
        windows = _rest_windows_from_activity_onset_offset(onsets, offsets, min_hours=min_hours, max_hours=max_hours)
        if windows:
            for window in windows:
                window["source"] = "estimated_rest_period"
                window["method"] = label
            return windows, {
                "source": "estimated_rest_period",
                "method": label,
                "estimated": True,
                "notes": notes + [f"Detected {len(windows)} rest window(s) from activity offset/onset times."],
            }
        notes.append(f"{label} ran, but no rest windows passed the duration filters ({min_hours}-{max_hours} h).")

    if settings.get("fallbackToLowActivity", True):
        fallback_windows = _detect_low_activity_rest_windows(
            raw,
            min_hours=min_hours,
            max_hours=max_hours,
            target_hours=settings.get("fallbackRestWindowHours") or settings.get("targetRestWindowHours"),
            search_start_hour=settings.get("fallbackSearchStartHour", 20),
            search_stop_hour=settings.get("fallbackSearchStopHour", 12),
        )
        if fallback_windows:
            details = _sleep_window_detail_payload(fallback_windows, {"method": "fallback_low_activity_window", "source": "estimated_rest_period", "estimated": True})
            summary = _summarize_sleep_window_details(details)
            fallback_notes = [
                "Crespo/Roenneberg AOT did not return usable arrays, so the UI used a fallback lowest-activity overnight window estimate.",
                f"Detected {len(fallback_windows)} fallback rest window(s).",
            ]
            if summary:
                fallback_notes.append(summary)
            return fallback_windows, {
                "source": "estimated_rest_period",
                "method": "fallback_low_activity_window",
                "estimated": True,
                "details": details,
                "notes": notes + fallback_notes,
            }
        notes.append("Fallback lowest-activity rest-window detection did not find a usable overnight window.")

    return [], {"source": "none", "method": None, "estimated": False, "notes": notes}


def _resolve_sleep_windows(raw, sleep_window_settings=None):
    diary_windows = _get_sleep_windows(raw)
    if diary_windows:
        return diary_windows, {
            "source": "sleep_diary",
            "method": "sleep_diary",
            "estimated": False,
            "count": len(diary_windows),
            "notes": [f"Using {len(diary_windows)} diary/user-defined sleep window(s)."],
        }

    detected_windows, metadata = _detect_rest_windows_with_pyactigraphy(raw, sleep_window_settings=sleep_window_settings)
    metadata["count"] = len(detected_windows)
    return detected_windows, metadata


def _score_minutes_in_windows(score, windows):
    series = _coerce_score_series(score)
    if series is None:
        return None
    if not windows:
        return _score_rest_minutes(series)

    epoch_minutes = _epoch_minutes(series.index)
    total_sleep_minutes = 0.0
    usable_windows = 0
    for window in windows:
        window_series = series.loc[window["start"]:window["stop"]].dropna()
        if len(window_series) == 0:
            continue
        usable_windows += 1
        total_sleep_minutes += float((window_series > 0).sum()) * epoch_minutes
    if usable_windows == 0:
        return None
    return total_sleep_minutes


def _compute_waso_and_efficiency(score, windows):
    series = _coerce_score_series(score)
    if series is None or not windows:
        return {
            "waso": None,
            "sleep_efficiency": None,
            "time_in_bed_minutes": None,
            "sleep_window_count": 0,
        }

    epoch_minutes = _epoch_minutes(series.index)
    total_sleep_minutes = 0.0
    total_waso_minutes = 0.0
    total_time_in_bed_minutes = 0.0
    usable_windows = 0

    for window in windows:
        start = window["start"]
        stop = window["stop"]
        if stop <= start:
            continue
        window_series = series.loc[start:stop].dropna()
        if len(window_series) == 0:
            continue

        sleep_mask = window_series > 0
        if not bool(sleep_mask.any()):
            # The diary window exists, but the chosen algorithm found no sleep in it.
            usable_windows += 1
            total_time_in_bed_minutes += (stop - start).total_seconds() / 60.0
            continue

        usable_windows += 1
        total_time_in_bed_minutes += (stop - start).total_seconds() / 60.0
        total_sleep_minutes += float(sleep_mask.sum()) * epoch_minutes

        first_sleep_pos = sleep_mask.to_numpy().nonzero()[0][0]
        after_onset = sleep_mask.iloc[first_sleep_pos:]
        total_waso_minutes += float((~after_onset).sum()) * epoch_minutes

    if usable_windows == 0 or total_time_in_bed_minutes <= 0:
        return {
            "waso": None,
            "sleep_efficiency": None,
            "time_in_bed_minutes": None,
            "sleep_window_count": 0,
        }

    return {
        "waso": total_waso_minutes,
        "sleep_efficiency": (total_sleep_minutes / total_time_in_bed_minutes) * 100.0,
        "time_in_bed_minutes": total_time_in_bed_minutes,
        "sleep_window_count": usable_windows,
    }


def compute_metric(raw, metric_id, params=None):
    params = params or {}

    if metric_id == "ra":
        return _safe_call(raw.RA, binarize=params.get("binarize", True), threshold=params.get("threshold", 4))

    if metric_id == "is":
        return _safe_call(raw.IS, freq=params.get("freq", "1min"), binarize=params.get("binarize", True), threshold=params.get("threshold", 4))

    if metric_id == "iv":
        return _safe_call(raw.IV, freq=params.get("freq", "1min"), binarize=params.get("binarize", True), threshold=params.get("threshold", 4))

    if metric_id == "ism":
        return _safe_call(raw.ISm, freqs=params.get("freqs") or DEFAULT_MEAN_FREQS, binarize=params.get("binarize", True), threshold=params.get("threshold", 4))

    if metric_id == "ivm":
        return _safe_call(raw.IVm, freqs=params.get("freqs") or DEFAULT_MEAN_FREQS, binarize=params.get("binarize", True), threshold=params.get("threshold", 4))

    if metric_id == "isp":
        return _safe_call(raw.ISp, period=params.get("period", "7D"), freq=params.get("freq", "1min"), binarize=params.get("binarize", True), threshold=params.get("threshold", 4), verbose=params.get("verbose", False))

    if metric_id == "ivp":
        return _safe_call(raw.IVp, period=params.get("period", "7D"), freq=params.get("freq", "1min"), binarize=params.get("binarize", True), threshold=params.get("threshold", 4), verbose=params.get("verbose", False))

    if metric_id == "rap":
        return _safe_call(raw.RAp, period=params.get("period", "7D"), binarize=params.get("binarize", True), threshold=params.get("threshold", 4), verbose=params.get("verbose", False))

    if metric_id == "kra":
        method = getattr(raw, "kRA", None)
        return _safe_call(method, threshold=params.get("threshold", 4), start=params.get("start") or None, period=params.get("period") or None, frac=params.get("frac", 0.3), it=params.get("it", 0), logit=params.get("logit", False), freq=params.get("freq", "1min")) if callable(method) else None

    if metric_id == "kar":
        method = getattr(raw, "kAR", None)
        return _safe_call(method, threshold=params.get("threshold", 4), start=params.get("start") or None, period=params.get("period") or None, frac=params.get("frac", 0.3), it=params.get("it", 0), logit=params.get("logit", False), freq=params.get("freq", "1min")) if callable(method) else None

    return None


def compute_sleep_metrics(raw, selected_metrics=None, algorithm_request=None, sleep_window_settings=None):
    results = {}
    selected_metrics = selected_metrics or []
    algorithm_request = algorithm_request or {}
    algorithm = algorithm_request.get("id", "cole_kripke")
    algorithm_params = {algorithm: algorithm_request.get("params", {})}

    scorer = _score_algorithm(raw, algorithm, algorithm_params=algorithm_params)
    sleep_windows, window_metadata = _resolve_sleep_windows(raw, sleep_window_settings=sleep_window_settings)
    rest_minutes = _score_minutes_in_windows(scorer, sleep_windows)
    sleep_window_summary = _compute_waso_and_efficiency(scorer, sleep_windows)

    if "sri" in selected_metrics:
        algo_key = ALGO_TO_SRI_KEY.get(algorithm)
        if algo_key is None:
            results["sri"] = None
        else:
            sri_method = getattr(raw, "SleepRegularityIndex", None)
            results["sri"] = _safe_call(sri_method, algo=algo_key) if callable(sri_method) else None

    if "tst" in selected_metrics:
        results["tst"] = round(rest_minutes, 2) if rest_minutes is not None else None

    if "waso" in selected_metrics:
        waso = sleep_window_summary.get("waso")
        results["waso"] = round(waso, 2) if waso is not None else None

    if "sleep_efficiency" in selected_metrics:
        sleep_efficiency = sleep_window_summary.get("sleep_efficiency")
        results["sleep_efficiency"] = round(sleep_efficiency, 2) if sleep_efficiency is not None else None

    if any(metric in selected_metrics for metric in ["tst", "waso", "sleep_efficiency"]):
        results["sleep_window_source"] = window_metadata.get("source") or "none"
        results["sleep_window_method"] = window_metadata.get("method") or "none"
        results["sleep_window_count"] = int(window_metadata.get("count") or sleep_window_summary.get("sleep_window_count") or 0)
        results["time_in_bed_minutes"] = round(sleep_window_summary.get("time_in_bed_minutes"), 2) if sleep_window_summary.get("time_in_bed_minutes") is not None else None
        results["sleep_window_estimated"] = bool(window_metadata.get("estimated"))
        details = window_metadata.get("details") or _sleep_window_detail_payload(sleep_windows, window_metadata)
        if details:
            results["sleep_window_details"] = details
            results["sleep_window_details_summary"] = _summarize_sleep_window_details(details) or None
        if window_metadata.get("notes"):
            results["sleep_window_notes"] = " | ".join([str(note) for note in window_metadata.get("notes", [])])

    return results


def _build_metric_requests_from_families(family_requests):
    metric_requests = []
    for family in family_requests or []:
        family_id = family.get("id")
        for metric_id in IMPLEMENTED_FAMILY_METRICS.get(family_id, []):
            metric_requests.append({"id": metric_id, "params": {}})
    return metric_requests


def _run_advanced_family_placeholder(family_id):
    return {
        "status": "planned",
        "family": family_id,
        "message": "{} is selected, but full backend execution is not yet implemented in this UI.".format(family_id),
    }


def _run_basic_pyactigraphy_analysis_single(raw, metric_requests=None, family_requests=None, analysis_scope="metric", algorithm_request=None, sleep_window_settings=None):
    metric_requests = metric_requests or []
    family_requests = family_requests or []
    results = {}

    if analysis_scope == "family":
        metric_requests = _build_metric_requests_from_families(family_requests)
        for family in family_requests:
            family_id = family.get("id")
            if family_id in ADVANCED_FAMILY_IDS:
                results[family_id] = _run_advanced_family_placeholder(family_id)

    rest_and_fragmentation_ids = {"ra", "is", "iv", "ism", "ivm", "isp", "ivp", "rap", "kra", "kar"}
    sleep_ids = {"sri", "tst", "waso", "sleep_efficiency"}

    selected_metric_ids = [item.get("id") for item in metric_requests if item.get("id")]

    for item in metric_requests:
        metric_id = item.get("id")
        params = item.get("params", {}) or {}
        if metric_id in rest_and_fragmentation_ids:
            value = compute_metric(raw, metric_id, params=params)
            results[metric_id] = _resolve_series_to_numeric(value)

    sleep_selected = [metric_id for metric_id in selected_metric_ids if metric_id in sleep_ids]
    if sleep_selected:
        results.update(compute_sleep_metrics(raw, selected_metrics=sleep_selected, algorithm_request=algorithm_request, sleep_window_settings=sleep_window_settings))

    for metric_id in selected_metric_ids:
        if metric_id not in results:
            results[metric_id] = None

    return results


def _normalize_analysis_windows(analysis_window_settings=None):
    settings = analysis_window_settings or {}
    if settings.get("mode") != "selected":
        return []

    windows = []
    for idx, interval in enumerate(settings.get("manualIntervals", []) or []):
        try:
            start = pd.to_datetime(interval.get("start"))
            stop = pd.to_datetime(interval.get("stop"))
            if pd.isna(start) or pd.isna(stop) or stop <= start:
                continue
            windows.append({
                "index": idx + 1,
                "label": interval.get("label") or "Analysis interval {}".format(idx + 1),
                "state": interval.get("state") or "ANALYSIS",
                "start": start,
                "stop": stop,
                "source": interval.get("source") or "manual_ui",
            })
        except Exception:
            continue
    return windows


def _slice_raw_to_window(raw, start, stop):
    window_raw = copy.copy(raw)
    if not hasattr(raw, "data") or raw.data is None:
        raise ValueError("Selected-interval analysis requires raw.data to be available on the loaded recording.")

    window_data = raw.data.loc[start:stop]
    if window_data is None or len(window_data) == 0:
        raise ValueError("No activity samples were found inside this selected interval.")

    try:
        window_raw.data = window_data.copy()
    except Exception:
        window_raw.data = window_data

    # Keep only sleep diary/rest windows that overlap this selected analysis interval.
    try:
        scoped_sleep_windows = []
        for window in getattr(raw, "_ui_sleep_windows", []) or []:
            w_start = pd.to_datetime(window.get("start"))
            w_stop = pd.to_datetime(window.get("stop"))
            if pd.isna(w_start) or pd.isna(w_stop) or w_stop <= start or w_start >= stop:
                continue
            next_window = dict(window)
            next_window["start"] = max(w_start, start).isoformat()
            next_window["stop"] = min(w_stop, stop).isoformat()
            scoped_sleep_windows.append(next_window)
        window_raw._ui_sleep_windows = scoped_sleep_windows
    except Exception:
        pass

    return window_raw


def _average_numeric_window_results(window_results, metric_ids):
    aggregate = {}
    for metric_id in metric_ids:
        values = []
        for item in window_results:
            value = (item.get("results") or {}).get(metric_id)
            if isinstance(value, bool):
                continue
            if isinstance(value, numbers.Number) and math.isfinite(float(value)):
                values.append(float(value))
        if values:
            aggregate[metric_id] = round(sum(values) / len(values), 4)
        else:
            aggregate[metric_id] = None
    return aggregate


def run_basic_pyactigraphy_analysis(raw, metric_requests=None, family_requests=None, analysis_scope="metric", algorithm_request=None, sleep_window_settings=None, analysis_window_settings=None):
    metric_requests = metric_requests or []
    family_requests = family_requests or []
    selected_metric_ids = [item.get("id") for item in metric_requests if item.get("id")]
    windows = _normalize_analysis_windows(analysis_window_settings)

    if not windows:
        return _run_basic_pyactigraphy_analysis_single(
            raw,
            metric_requests=metric_requests,
            family_requests=family_requests,
            analysis_scope=analysis_scope,
            algorithm_request=algorithm_request,
            sleep_window_settings=sleep_window_settings,
        )

    window_results = []
    for window in windows:
        payload = {
            "index": window["index"],
            "label": window["label"],
            "state": window["state"],
            "start": window["start"].isoformat(),
            "stop": window["stop"].isoformat(),
            "duration_hours": round((window["stop"] - window["start"]).total_seconds() / 3600.0, 4),
        }
        try:
            scoped_raw = _slice_raw_to_window(raw, window["start"], window["stop"])
            payload["results"] = _run_basic_pyactigraphy_analysis_single(
                scoped_raw,
                metric_requests=metric_requests,
                family_requests=family_requests,
                analysis_scope=analysis_scope,
                algorithm_request=algorithm_request,
                sleep_window_settings=sleep_window_settings,
            )
        except Exception as exc:
            payload["results"] = {}
            payload["error"] = str(exc)
        window_results.append(payload)

    aggregate = _average_numeric_window_results(window_results, selected_metric_ids)
    aggregate["analysis_window_mode"] = "selected_intervals"
    aggregate["analysis_window_count"] = len(window_results)
    aggregate["analysis_window_summary"] = "Top-level numeric metrics are means across selected intervals; open Analysis window details for per-interval values."
    aggregate["analysis_windows"] = window_results
    return aggregate



def _index_timezone_info(index):
    tz = getattr(index, "tz", None)
    if tz is None:
        return {
            "timezone_aware": False,
            "timezone": None,
            "note": "Timestamps are timezone-naive. pyActigraphy calculations use the timestamps as stored in the file; confirm the device/export timezone before interpreting clock-time metrics.",
        }
    return {
        "timezone_aware": True,
        "timezone": str(tz),
        "note": "Timestamps include timezone information. Clock-time plots and metrics are shown using the timezone stored on the DateTimeIndex.",
    }


def _mean_daily_wave(series, value_key="mean_activity", max_points=1440):
    if series is None or len(series) == 0:
        return []
    wave = pd.to_numeric(series, errors="coerce").dropna()
    if len(wave) == 0:
        return []
    if not isinstance(wave.index, pd.DatetimeIndex):
        return []
    try:
        if getattr(wave.index, "freq", None) is None:
            inferred = pd.infer_freq(wave.index)
            if inferred is None:
                median_step = pd.Series(wave.index).diff().dropna().median()
                if pd.notna(median_step):
                    inferred = pd.Timedelta(median_step)
            if inferred is not None:
                wave = wave.resample(inferred).mean().dropna()
    except Exception:
        pass
    grouped = wave.groupby(wave.index.strftime("%H:%M")).mean().sort_index()
    if len(grouped) > max_points:
        step = max(1, len(grouped) // max_points)
        grouped = grouped.iloc[::step]
    return [{"time": str(idx), value_key: _safe_float(value)} for idx, value in grouped.items()]


def _sample_full_recording(series, max_points=2000, value_key="activity"):
    if series is None or len(series) == 0:
        return []

    total = len(series)
    step = max(1, total // max_points)
    sampled = series.iloc[::step]

    return [{"timestamp": str(index), value_key: _safe_float(value)} for index, value in sampled.items()]


def build_native_preview(raw, activity_channel="data", resample_freq=None):
    series = getattr(raw, "data", None)
    if series is None:
        raise ValueError("Unable to read the activity signal for preview.")

    preview_series = series.dropna()
    if resample_freq:
        preview_series = preview_series.resample(resample_freq).mean()

    timezone_info = _index_timezone_info(preview_series.index) if len(preview_series) else _index_timezone_info(series.index)
    mean_activity_wave = _mean_daily_wave(preview_series, value_key="mean_activity")
    summary = {
        "rows": int(len(preview_series)),
        "start": str(preview_series.index.min()) if len(preview_series) else None,
        "end": str(preview_series.index.max()) if len(preview_series) else None,
        "activity_channel": activity_channel,
        "resample_freq": resample_freq,
        "preview_mode": "full_recording",
        "device": getattr(raw, "format", None),
        "timezone_aware": timezone_info.get("timezone_aware"),
        "timezone": timezone_info.get("timezone") or "Not provided in file/index",
        "mean_activity_wave_points": len(mean_activity_wave),
    }

    return {
        "preview_available": True,
        "summary": summary,
        "timezone_info": timezone_info,
        "full_recording_preview": _sample_full_recording(preview_series, value_key="activity"),
        "mean_activity_wave": mean_activity_wave,
    }


def _describe_light_scale(raw, channel_name):
    metadata = getattr(raw, "metadata", None) or {}
    channel_scales = metadata.get("light_channels") if isinstance(metadata, dict) else None
    scale = None
    if isinstance(channel_scales, dict) and channel_name:
        scale = channel_scales.get(channel_name) or channel_scales.get(str(channel_name).upper())

    if not scale and channel_name:
        normalized = str(channel_name).strip().upper()
        if normalized in {"LIGHT_LOG", "LOG_LIGHT", "LOG10_LUX", "LIGHT", "WHITE_LIGHT", "AMB_LIGHT"} and metadata.get("direct_geneactiv_reader"):
            scale = "log10(lux + 1)"
        elif "LUX" in normalized:
            scale = "lux"

    if not scale:
        scale = "lux"

    if str(scale).lower() == "log10(lux + 1)":
        return {
            "light_channel": channel_name,
            "light_units": "log10(lux + 1)",
            "light_scale": "log10_lux_plus_one",
            "y_axis_label": "Light intensity, log10(lux + 1)",
            "light_scale_note": "values are log10-transformed from lux to make low and high light exposure easier to view",
        }

    return {
        "light_channel": channel_name,
        "light_units": "lux",
        "light_scale": "lux",
        "y_axis_label": "Light intensity (lux)",
        "light_scale_note": "values are shown in raw lux",
    }


def build_light_preview(raw, resample_freq=None):
    light_series = None
    light_channel_name = None

    # Native pyActigraphy readers like ATR/MTN expose LightRecording plus
    # convenience properties such as white_light / amb_light.
    if hasattr(raw, "white_light") and raw.white_light is not None:
        light_series = raw.white_light
        light_channel_name = "white_light"
    elif hasattr(raw, "amb_light") and raw.amb_light is not None:
        light_series = raw.amb_light
        light_channel_name = "amb_light"
    else:
        light_obj = getattr(raw, "light", None)

        if light_obj is None:
            return {
                "light_preview_available": False,
                "light_preview": [],
                "light_summary": {},
            }

        # If light is already a pandas Series
        if hasattr(light_obj, "dropna"):
            light_series = light_obj

        # If light is a LightRecording, try common channel names
        elif hasattr(light_obj, "get_channel"):
            for channel_name in ["LIGHT", "whitelight", "AMB LIGHT", "LIGHT_LUX", "Lux", "lux"]:
                try:
                    candidate = light_obj.get_channel(channel_name)
                    if candidate is not None:
                        light_series = candidate
                        light_channel_name = channel_name
                        break
                except Exception:
                    pass

            # Fall back to the first available column in the LightRecording dataframe
            if light_series is None and hasattr(light_obj, "data") and light_obj.data is not None:
                try:
                    if len(light_obj.data.columns) > 0:
                        light_series = light_obj.data.iloc[:, 0]
                        light_channel_name = str(light_obj.data.columns[0])
                except Exception:
                    pass

    if light_series is None:
        return {
            "light_preview_available": False,
            "light_preview": [],
            "light_summary": {},
        }

    preview_series = light_series.dropna()
    if len(preview_series) == 0:
        return {
            "light_preview_available": False,
            "light_preview": [],
            "light_summary": {},
        }

    if resample_freq:
        preview_series = preview_series.resample(resample_freq).mean()

    timezone_info = _index_timezone_info(preview_series.index)
    scale_info = _describe_light_scale(raw, light_channel_name)
    summary = {
        "rows": int(len(preview_series)),
        "start": str(preview_series.index.min()) if len(preview_series) else None,
        "end": str(preview_series.index.max()) if len(preview_series) else None,
        "mean_light": _serialize_scalar(preview_series.mean()) if len(preview_series) else None,
        "max_light": _serialize_scalar(preview_series.max()) if len(preview_series) else None,
        "timezone_aware": timezone_info.get("timezone_aware"),
        "timezone": timezone_info.get("timezone") or "Not provided in file/index",
        **scale_info,
    }

    return {
        "light_preview_available": True,
        "timezone_info": timezone_info,
        "light_y_axis_label": scale_info.get("y_axis_label"),
        "light_units": scale_info.get("light_units"),
        "light_scale": scale_info.get("light_scale"),
        "light_preview": _sample_full_recording(preview_series, value_key="light"),
        "light_summary": summary,
    }

def _get_light_channel_series(raw, channel_name):
    light_obj = _get_light_recording(raw)
    if light_obj is None:
        return None

    try:
        series = light_obj.get_channel(channel_name)
    except Exception:
        series = None

    if series is None:
        return None

    if isinstance(series, pd.DataFrame):
        if series.shape[1] == 0:
            return None
        series = series.iloc[:, 0]

    if not isinstance(series, pd.Series):
        return None

    return series.dropna()


def _sample_multichannel_dataframe(df, max_points=1200):
    if df is None or df.empty:
        return []

    df = df.sort_index()

    if len(df) > max_points:
        step = max(1, len(df) // max_points)
        df = df.iloc[::step]

    rows = []
    for idx, row in df.iterrows():
        point = {"timestamp": str(idx)}
        for col in df.columns:
            value = row[col]
            point[col] = None if pd.isna(value) else _serialize_scalar(value)
        rows.append(point)

    return rows


def build_light_rgb_preview(raw, resample_freq="5min"):
    light_obj = _get_light_recording(raw)
    if light_obj is None:
        return {
            "light_preview_available": False,
            "channels": [],
            "rgb_preview": [],
            "rgb_summary": {},
        }

    available_channels = _get_light_channels(raw)

    preferred_channels = [
        "RED LIGHT",
        "GREEN LIGHT",
        "BLUE LIGHT",
        "LIGHT",
        "AMB LIGHT",
        "IR LIGHT",
        "UVA LIGHT",
        "UVB LIGHT",
    ]

    selected_channels = [ch for ch in preferred_channels if ch in available_channels]

    if not selected_channels and available_channels:
        selected_channels = available_channels[:4]

    channel_series = {}
    for channel in selected_channels:
        series = _get_light_channel_series(raw, channel)
        if series is None or len(series) == 0:
            continue

        if resample_freq:
            try:
                series = series.resample(resample_freq).mean()
            except Exception:
                pass

        series = series.dropna()
        if len(series) == 0:
            continue

        channel_series[channel] = series.rename(channel)

    if not channel_series:
        return {
            "light_preview_available": False,
            "channels": available_channels,
            "rgb_preview": [],
            "rgb_summary": {},
        }

    preview_df = pd.concat(channel_series.values(), axis=1)

    channel_scale_info = {channel: _describe_light_scale(raw, channel) for channel in preview_df.columns}
    y_axis_labels = sorted({info.get("y_axis_label") for info in channel_scale_info.values() if info.get("y_axis_label")})
    if len(y_axis_labels) == 1:
        y_axis_label = y_axis_labels[0]
        scale_note = next((info.get("light_scale_note") for info in channel_scale_info.values() if info.get("light_scale_note")), "")
    else:
        y_axis_label = "Light intensity (mixed units/scales)"
        scale_note = "selected channels may use different units; check each channel card for units"

    summary = {
        "rows": int(len(preview_df)),
        "start": str(preview_df.index.min()) if len(preview_df) else None,
        "end": str(preview_df.index.max()) if len(preview_df) else None,
        "channels_used": list(preview_df.columns),
        "y_axis_label": y_axis_label,
        "light_scale_note": scale_note,
        "channel_stats": {},
    }

    for channel in preview_df.columns:
        series = preview_df[channel].dropna()
        scale_info = channel_scale_info.get(channel, {})
        summary["channel_stats"][channel] = {
            "mean": _serialize_scalar(series.mean()) if len(series) else None,
            "max": _serialize_scalar(series.max()) if len(series) else None,
            "min": _serialize_scalar(series.min()) if len(series) else None,
            "units": scale_info.get("light_units"),
            "scale": scale_info.get("light_scale"),
            "y_axis_label": scale_info.get("y_axis_label"),
        }

    return {
        "light_preview_available": True,
        "channels": available_channels,
        "rgb_preview": _sample_multichannel_dataframe(preview_df),
        "rgb_summary": summary,
    }