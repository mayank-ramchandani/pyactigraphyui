# Choosing an activity representation

An optional **raw-signal preprocessing** panel is available in **Step 2: Preprocessing/Initial QC** (off by default), followed by the activity measure selected on **Step 3: Estimating Activity Metric**. It becomes the epoch-level signal used by the selected rest-activity analyses.

## Recommended choice

Use **Recommended source / processed acc** unless the study protocol requires a specific measure.

- Files that already contain device activity or counts use that source series.
- Supported raw `.bin`, `.cwa`, and `.gt3x` files use an epoch-level processed acceleration series.

This setting provides a consistent default while preserving the original count scale when a file is already count-based.

## Available measures

| Measure | What it represents | Typical units |
|---|---|---|
| Recommended source / processed acc | Source activity when supplied; otherwise processed epoch-level acceleration | Source-dependent or mg |
| Processed acceleration (acc) | Gravity-adjusted acceleration summarized by epoch | mg |
| ENMO | Positive Euclidean Norm Minus One summarized by epoch | mg |
| MAD | Mean amplitude deviation of vector magnitude within an epoch | mg |
| PIM | Integral of unfiltered `|VM - 1 g|`, including the native sample interval | mg·s/epoch |
| ZCM | Level crossings of a positive threshold in unfiltered `|VM - 1 g|` | crossings/epoch |
| TAT | Time above a positive threshold in unfiltered `|VM - 1 g|` | s/epoch |

## How to choose

Choose a specific measure when:

- it is required by the study protocol;
- you need comparability with a previous analysis;
- a validated threshold or interpretation is tied to that signal;
- the selected file already contains the desired epoch-level column.

Do not compare thresholds across counts, mg, mg·s/epoch, and crossings/epoch as though they were the same scale.

## Raw accelerometer files

Raw X/Y/Z acceleration must be reduced to one scalar epoch-level series before pyActigraphy metrics can be calculated. With Step 2 custom preprocessing turned off, ActiLab uses metric-specific pipelines rather than one universal filter:

- **ENMO:** unfiltered vector magnitude → subtract 1 g → truncate negative values to zero → epoch mean.
- **MAD:** unfiltered vector magnitude → within-epoch mean amplitude deviation.
- **PIM:** unfiltered `|VM - 1 g|` → integrate using the native sampling interval.
- **ZCM:** unfiltered `|VM - 1 g|` → count transitions across the selected positive threshold.
- **TAT:** unfiltered `|VM - 1 g|` → accumulate seconds above the selected positive threshold.
- **Processed acceleration (`acc`):** uses its separately documented processed-acceleration path and is not relabelled as ENMO, MAD, PIM, ZCM, or TAT.

This distinction matters because filtering individual axes before calculating vector magnitude is not mathematically equivalent to filtering vector magnitude afterward. Maczák et al. found that preprocessing order could materially change the resulting activity series and emphasized complete reporting of the signal-processing definition ([Maczák et al., 2021](https://doi.org/10.1371/journal.pone.0261718)).

The exact resolved measure, units, epoch duration, and processing details are included with the results.

## Optional filtering, magnitude and normalization in Step 2

Enable **Custom raw acceleration preprocessing** to choose low-pass, high-pass or band-pass Butterworth filtering, orders 1–8, corner frequencies (Hz), and whether filtering happens on each calibrated axis **before magnitude** or on the combined magnitude **after**. Magnitude means `sqrt(X² + Y² + Z²)`; per-axis and magnitude-first filtering are different operations. You may select uncorrected magnitude, absolute amplitude, signed gravity subtraction, absolute gravity deviation, or positive deviation (ENMO), plus an optional 1 g reference and output units (mg, g, m/s²). High-/band-pass filter choices that remove static gravity cannot be combined with subtraction of another 1 g.

Filtering is causal and forward-only, implemented on native high-frequency GT3X and GENEActiv BIN samples, and has state resets at recording gaps. Custom processing **does not run** on already-aggregated or converted activity files, including current CWA conversions. It does not reinterpret device count data as raw acceleration. Configured ZCM/TAT thresholds remain in mg. Not all custom signals have established sleep classification thresholds. See [the full preprocessing description](PREPROCESSING_AND_PROVENANCE.md) and [Maczák et al. (2021)](https://doi.org/10.1371/journal.pone.0261718).

## Joining recordings with different native sampling rates

When **Join as one participant timeline** is selected, ActiLab distinguishes the device's **native/raw sampling rate** (for example, 30 Hz or 100 Hz) from the **analytical epoch** used for actigraphy analysis (for example, 30-second epochs).

ActiLab does **not** concatenate raw samples recorded at different frequencies. Instead, each source recording is processed independently at its own native sampling rate into the selected activity representation, summarized to the same analytical epoch, and only then joined by timestamp. Original timestamps and true gaps between recordings are preserved. Native sampling rates are retained in QC, preview information, results, and provenance.

For joined files with different native sampling rates:

| Activity representation | Behaviour |
|---|---|
| ENMO | Join allowed with an informational notice |
| Processed acceleration | Join allowed with an informational notice |
| MAD | Join allowed with a warning |
| PIM | Join allowed with a warning |
| ZCM | Join allowed with a strong warning because zero-crossing counts are sampling-frequency sensitive |
| TAT | Join allowed with a warning; duration includes the native sample interval |
| Source/device activity or ActiGraph counts | Join blocked across differing native sampling rates unless the inputs have already been externally harmonized/validated |

The join is also blocked if the processed epoch durations differ or if the files resolve to different activity measures or units. Matching the analytical epoch does not mean that the original recordings had the same sampling rate; ActiLab records that distinction explicitly.

## Existing time-series columns

For Oxford time-series and mapped tabular files, an existing acc, ENMO, MAD, PIM, ZCM, TAT, or activity column can be used directly. Confirm that the column units, threshold definition, and epoch duration are correct before analysis. Selecting an existing column does not reconstruct raw-signal processing.

## ZCM and TAT thresholds

ZCM and TAT require a positive threshold above measurement noise. ActiLab offers:

- **Adaptive (SD of the recording):** calculates the standard deviation of unfiltered `|VM - 1 g|` across valid decoded raw samples, then applies that one threshold to the complete recording in a second streaming pass.
- **Fixed threshold:** applies the entered mg value to the complete recording.

Maczák et al. proposed the standard deviation of the chosen input dataset as an adaptive threshold for ZCM and TAT because it produced strong correlations with ENMO and HFEN in their data. This is a methodological option, not proof of universal clinical validity. Their study used correlation-based comparisons in 42 healthy young adults, so thresholds should be justified for the device, population, placement, and research question.

For joined-participant ZCM or TAT, ActiLab requires a fixed threshold. That ensures all source recordings use the same metric definition. Adaptive thresholds are estimated per recording only when files are analyzed separately; later non-wear masks are intentionally kept in the actigraphy-preprocessing layer and do not silently redefine the raw-signal threshold.

Mapping a generic activity column labels and uses that column as supplied. It does not reconstruct raw X/Y/Z processing.

## Missingness and masks

After the activity series is created:

1. timestamps are regularized at the detected epoch duration;
2. missing values remain missing;
3. start/stop limits are applied;
4. non-wear and masks are applied;
5. quality-window and sleep-window coverage are calculated;
6. eligible metrics are run.

Recorded zeros remain data. Missing, masked, and non-wear epochs do not become zero activity.

## Binarization and thresholds

Some analyses can use continuous activity, while others may use a thresholded active/rest series. Keep thresholds tied to the selected signal and units. The chosen binarization setting and threshold are included in the exported analysis configuration.

## pyActigraphy references

- [pyActigraphy documentation](https://ghammad.github.io/pyActigraphy/)
- [pyActigraphy source code](https://github.com/ghammad/pyActigraphy)
- [pyActigraphy package paper](https://doi.org/10.1371/journal.pcbi.1009514)
- [Maczák et al. (2021), *Detailed analysis and comparison of different activity metrics*](https://doi.org/10.1371/journal.pone.0261718)
